<?php
class importar2{
    protected function _construct(){

    }


}