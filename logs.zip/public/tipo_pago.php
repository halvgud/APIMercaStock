<?php

class tipo_pago
{
    protected function __construct(){
    }


}