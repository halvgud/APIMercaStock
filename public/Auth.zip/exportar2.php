<?php
class exportar2{
    protected function _construct(){

    }


}